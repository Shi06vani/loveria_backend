import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import db from "../models/index.js";
import sendResponse, { errorResponse } from "../utils/response.js";

const { Auth } = db;

// helper to generate JWT
const generateToken = (payload) => {
  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: "7d",
  });
};

/**
 * SIGNUP
 */
export const signup = async (req, res) => {
  try {
    const { name, email, contact, password } = req.body;


    // check existing user
    const existingUser = await Auth.findOne({ where: { email } });
    if (existingUser) {
      return sendResponse(res, false, 409, {}, "Email already exists");
    }

    // hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    const user = await Auth.create({
      name,
      email,
      contact,
      password: hashedPassword,
    });

    return sendResponse(
      res,
      true,
      201,
      {
        id: user.id,
        name: user.name,
        email: user.email,
      },
      "Signup successful"
    );
  } catch (error) {
    return errorResponse(res, error.message, 500);
  }
};

/**
 * LOGIN
 */
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // find user
    const user = await Auth.findOne({ where: { email } });
    if (!user) {
      return sendResponse(res, false, 401, {}, "Invalid email or password");
    }

    // compare password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return sendResponse(res, false, 401, {}, "Invalid email or password");
    }

    // create token (keep payload minimal)
    const token = generateToken({
      id: user.id,
      role: user.role || "user",
    });

    return sendResponse(
      res,
      true,
      200,
      {
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          contact: user.contact,
        },
      },
      "Login successful"
    );
  } catch (error) {
    return errorResponse(res, error.message, 500);
  }
};
